public class DataTypeDemo {
    public static void main(String[] args) {
        int intVar = 25;
        float floatVar = 3.14f;
        double doubleVar = 123.456;
        char charVar = 'A';
        boolean boolVar = true;

        System.out.println("Integer: " + intVar);
        System.out.println("Float: " + floatVar);
        System.out.println("Double: " + doubleVar);
        System.out.println("Character: " + charVar);
        System.out.println("Boolean: " + boolVar);
    }
}
