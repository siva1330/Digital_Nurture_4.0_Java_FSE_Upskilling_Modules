package com.utils;

public class Utility {
    public static void greet() {
        System.out.println("Hello from Utility class!");
    }
} 